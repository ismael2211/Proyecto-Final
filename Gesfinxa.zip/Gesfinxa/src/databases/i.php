<?php

$servidor = "localhost";
$usuari = "root";
$contrasenya = "";
$basedades = "clientes";
$nom_taula = "fincas";
$conexion = mysqli_connect($servidor, $usuari, $contrasenya, $basedades);
if ($conexion) {

    $titulo = utf8_decode($_POST['titulo']);
    $metros = utf8_decode($_POST['metros']);
    $precio = utf8_decode($_POST['precio']);
    $habitaciones = utf8_decode($_POST['habitaciones']);

    // $imagen = $_FILES['imagen']['name'];//obtiene el nombre
    // $ruta = $_FILES['imagen']['tmp_name'];//contiene el archivo
    // echo $imagen;
    // $destino = "fotos/".$imagen;
    // copy($ruta, $destino);

    // move_uploaded_file($archivo,$ruta);


    // if(isset($imagen) && $imagen != ""){
    //     $tipo = $_FILES['imagen']['type'];
    //     $temp = $_FILES['imagen']['tmp_name'];

    //     if( !((strpos($tipo , 'gif') || strpos($tipo , 'jpg') || strpos($tipo, 'jpeg')))){
            
    //     }
    // }


    $sql = "INSERT into clientes.fincas (titulo,metros,precio,habitaciones) values ('$titulo' , '$metros' , '$precio' , '$habitaciones')";


    $resultado = mysqli_query($conexion, $sql);

    if ($resultado) {
        echo 2;
        // echo "Los datos han sido agregados correctamente";
    } else {
        echo 1;
        // echo "No se puedo realizar la accion";
    }
}
mysqli_close($conexion);
