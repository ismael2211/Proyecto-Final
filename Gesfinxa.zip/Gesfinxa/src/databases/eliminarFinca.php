<?php
 error_reporting(E_ALL ^ E_NOTICE);
 session_start();

 $servidor = "localhost";
 $usuari = "root";
 $contrasenya = "";
 $basedades = "clientes";
 $nom_taula = "fincas";
 $conexion = mysqli_connect($servidor, $usuari, $contrasenya, $basedades);

$idFinca = $_REQUEST['idFinca'];
var_dump($idFinca);

$sql = "DELETE FROM clientes.fincas WHERE idFinca = '$idFinca'";
mysqli_query($conexion, $sql);