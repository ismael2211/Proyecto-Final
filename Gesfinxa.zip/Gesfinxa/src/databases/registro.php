<?php
session_start();
include("./conexion.php");
 

$name = utf8_decode($_POST['nombre']);
$email = utf8_decode($_POST['correo']);
$pass = utf8_decode($_POST['contra']);

// Encriptar contraseña
$pass = md5($pass);
 
$resultado=mysqli_query($connexio ,  "SELECT * FROM ".$nom_taula." WHERE correo = '".$email."'");
 
if (mysqli_num_rows($resultado)>0)
{
   echo 1;
   // die();
 
} else {
 
 $insert_value = 'INSERT INTO `' . $basedades . '`.`'.$nom_taula.'` (`Nombre` , `Correo` , `Contra`) VALUES ("' . $name . '", "' . $email . '", "' . $pass . '")';
 
mysqli_select_db($connexio, $basedades);
$retry_value = mysqli_query($connexio, $insert_value);
 
if (!$retry_value) {
   die('Error: ' . mysqli_error($connexio));
}
 
}
 
mysqli_close($connexio);
