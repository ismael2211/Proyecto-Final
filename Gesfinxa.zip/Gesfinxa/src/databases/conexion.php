<?php

$servidor="localhost";
$usuari="root";
$contrasenya="";
$basedades="clientes";
$nom_taula="login";


$connexio = mysqli_connect($servidor, $usuari, $contrasenya, $basedades);

if($connexio) {
    mysqli_select_db($connexio , $basedades);
}