
<?php
include('conexion.php');
$id = $_REQUEST['id'];
$nombre      = $_REQUEST['nombre'];
$correo      = $_REQUEST['correo'];
$contra      = $_REQUEST['contra'];
$sql = "SELECT * FROM clientes.login WHERE correo = '$correo' and nombre = '$nombre'";
$resultat = mysqli_query($connexio, $sql);

// Comprobar si el correo existe en la Bd
if (mysqli_num_rows($resultat) == 0) {
	$update = ("UPDATE clientes.login 
	SET 
	nombre  ='" . $nombre . "',
	correo  ='" . $correo . "',
	contra ='" . $contra . "' 

WHERE id='" . $id . "'
");
	$result_update = mysqli_query($connexio, $update);

	echo "<script type='text/javascript'>
        window.location='../index.php';
		
    </script>";
}
else{
	echo "<script type='text/javascript'>
	alert('El usuario $correo ya existe en la base de datos, cambialo por otro.');

	document.location=('../index.php');

    </script>";
}
?>
