<?php

session_start();
include("conexion.php");

$email = ($_POST['correo']);
$contra = md5($_POST['contra']);

$sql = "SELECT correo FROM clientes.login WHERE correo = '$email' and contra='$contra'";
$resultat = mysqli_query($connexio , $sql);

if (mysqli_num_rows($resultat) > 0)
{

    $_SESSION["correoLogado"] = $email;
    // $_SESSION["nombreLogado"] = $nombre;
    if($email == "admin@gmail.com"){
        // $_SESSION["correo"] = $admin;
        // header("Location: ./admin.php");
        
        echo 2;
        
        
    }else{
        echo 1;
    }
}
else
{
    echo "ERROR";
}
mysqli_close($connexio);
