<?php
 error_reporting(E_ALL ^ E_NOTICE);
 session_start();

include "conexion.php";

$id = $_REQUEST['id'];

$sql = "DELETE FROM clientes.login WHERE id = '$id'";
mysqli_query($connexio, $sql);

