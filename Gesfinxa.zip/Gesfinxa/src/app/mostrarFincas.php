<?php
session_start();
$servidor = "localhost";
$usuari = "root";
$contrasenya = "";
$basedades = "clientes";
$nom_taula = "fincas";
$conexion = mysqli_connect($servidor, $usuari, $contrasenya, $basedades);
?>

<?php
$sql = "SELECT * FROM $nom_taula";
$consulta = mysqli_query($conexion, $sql);

while ($ver = mysqli_fetch_assoc($consulta)) {
?>

    <article>
        <figure>
            <img src="../src/assets/images/duplex.jpg" class="zoom" /><br>
            <figcaption>
                <h4><?php echo $ver['titulo']; ?></h4>
            </figcaption>
            <button style="font-size:12px; border-radius:15px;" type="button" class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#modal<?php echo $ver['idFinca']; ?>">
                Información
            </button>
            <br>
            <button style="font-size:12px; border-radius:15px;" type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete2<?php echo $ver['idFinca']; ?>">
                Eliminar</button>
            <div class="check"><br>
            </div>
        </figure>
    </article>
    
    <div class="modal fade" id="modal<?php echo $ver['idFinca']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body" id="cont_modal">

                    <div class="modal-header" style="background-color: #D5CDCB !important;">
                        <h6 style="text-transform: uppercase;" id="title"><?php echo $ver['titulo']; ?></h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <hr>
                    <div>
                        <p id="price" style="text-decoration: underline overline;" class="text-success font-weight-bold">Precio : <?php echo $ver['precio'] ?> €</p>
                        <p id="metros2" style="text-indent: 1em;" class="text-primary font-weight-bold"><?php echo $ver['metros'] ?>m²</p>
                        <p id="habi" style="text-indent: 1em;" class="text-primary font-weight-bold"><?php echo $ver['habitaciones'] ?> habitaciones</p>

                    </div>
                    <hr>
                </div>
                <div class="modal-body">
                    <div style="width: 100%"><iframe width="100%" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=300&amp;hl=en&amp;q=Comunidad%20valenciana+()&amp;t=h&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
                </div>
            </div>
        </div>
    </div>
    <?php include('borrarFinca.php'); ?>
<?php
}
?>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.btnBorrarFinca').click(function(e) {
            
            e.preventDefault();
            var idFinca = $(this).attr("idFinca");
            $.ajax({
                type: "POST",
                url: "./databases/eliminarFinca.php",
                data: 'idFinca=' + idFinca,
                success: function(data) {
                    // window.location.href = "./index.php";
                }
            });
            return false;
        });
    });
</script>