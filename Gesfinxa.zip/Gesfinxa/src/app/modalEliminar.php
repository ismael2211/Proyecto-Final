<!-- Ventana modal para eliminar Usuario -->
  <div class="modal fade" id="delete<?php echo $mostrar['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">
            ¿Realmente desea eliminar a: ?
          </h4>
        </div>
        
        <div class="modal-body">
          <strong style="text-align: center !important">
            <?php echo $mostrar['correo']; ?>

          </strong>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger btnBorrar" data-dismiss="modal" id="<?php echo $mostrar['id']; ?>">Borrar</button>
        </div>
      </div>
    </div>
  </div>
<!---fin ventana eliminar--->