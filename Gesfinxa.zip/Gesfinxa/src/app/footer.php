<footer class="bgDark">
    <div class="container">
        <img src="assets/images/logoOscuro.png" class="logo-brand" alt="logo">
        <ul class="list-inline">
            <span style="font-size:18px" class="badge badge-pill badge-light">gesfinxa@dvs-b.com</span>&nbsp;&nbsp;&nbsp;
            <span style="font-size:18px" class="badge badge-pill badge-light">Baixada de l'estació, 7</span>&nbsp;&nbsp;&nbsp;
            <span style="font-size:18px" class="badge badge-pill badge-light">924 612 747</span>

        </ul>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="https://www.instagram.com/_ismael_2000/?hl=es" target="_blank"><img src="assets/images/instagram.svg" class="img-fluid i"></a></li>
            <li class="list-inline-item"><a href="https://www.tiktok.com/@_ismael_2000?lang=es" target="_blank"><img src="assets/images/tiktok.svg" class="img-fluid i"></a></li>
            <li class="list-inline-item"><a href="https://twitter.com/ismaelghanitoma" target="_blank"><img src="assets/images/twitter.svg" class="img-fluid i"></a></li>
            <li class="list-inline-item"><a href="https://www.facebook.com/isma.ghanitomas/" target="_blank"><img src="assets/images/facebook.svg" class="img-fluid i"></a></li>
        </ul>
        <hr>
        <small>© 2021 All Rights Reserved.
    </div>
</footer>