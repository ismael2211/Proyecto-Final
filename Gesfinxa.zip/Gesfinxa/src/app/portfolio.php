<section id="portfolio">
        <div class="container-fluid ">
            <div class="content-center">
                <h1>DESPACHO ONLINE <span id="typed"></span></h1><br>
                <p>Con nuestro servicio jurídico, los administrados pueden realizar sus propias consultas jurídicas,
                    bien en el despacho o a través de correo electrónico. Mantenemos la consultoría al día gracias a
                    contar en nuestro despacho con titulados en Gestión de Comunidades, Empresariales y Derecho.</p>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="portfolio-container">
                        <div class="portfolio-details">
                            <a href="#inicioSesion">
                                <h2>Accede a tu comunidad</h2>
                            </a>
                        </div>
                        <img style="opacity: 0.7;" src="assets/images/edificio.jpeg" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="portfolio-container">
                        <div class="portfolio-details">
                            <a href="#inicioSesion">
                                <b>
                                    <h2>Realiza tu consulta</h2>
                                </b>
                            </a>
                        </div>
                        <img style="opacity: 0.7;" src="assets/images/1.jpg" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="portfolio-container">
                        <div class="portfolio-details">
                            <a href="#inmo" >
                                <h2>Ve las ofertas</h2>
                            </a>
                        </div>
                        <img style="opacity: 0.7;" src="assets/images/inmo.jpg" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="portfolio-container">
                        <div class="portfolio-details">
                            <a href="#info" id="pulsar">
                                <h2>Ven a conocernos</h2>
                            </a>
                        </div>
                        <img style="opacity: 0.7;" src="assets/images/ges.jpg" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </section>