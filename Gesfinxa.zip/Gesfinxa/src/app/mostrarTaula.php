<?php
session_start();
$connexio = mysqli_connect('localhost', 'root', '', 'clientes');
var_dump($_SESSION);

?>
    <table style="margin: 0 auto;" class="table table-striped table-responsive-lg">
        <thead class="table-dark">
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Nombre</th>
                <th scope="col">Correo</th>
                <th scope="col">Contraseña</th>
                <th scope="col" colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM clientes.login";
            $consulta = mysqli_query($connexio, $sql);

            while ($mostrar = mysqli_fetch_assoc($consulta)) {
            ?>
                <tr>
                    <td><?php echo $mostrar['id'] ?></td>
                    <td><?php echo $mostrar["nombre"] ?></td>
                    <td><?php echo $mostrar["correo"] ?></td>
                    <td>******************</td>

                    <?php if ($mostrar['correo'] == "admin@gmail.com") {
                    ?>
                        <td colspan="2">Acción no disponible</td>
                    <?php
                    } else {
                    ?>
                        <td> <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo $mostrar['id']; ?>">
                                Eliminar &nbsp;&nbsp;<i class="fas fa-trash-alt"></i>
                            </button></td>

                        <td><button type="button" class="btn btn-warning" data-toggle="modal" data-target="#edit<?php echo $mostrar['id']; ?>">
                                Modificar &nbsp;&nbsp;<i class="fas fa-pencil-alt"></i>
                            </button></td>
                    <?php
                    } ?>

                </tr>
                <!--Ventana Modal para la Alerta de Editar--->
                <?php include('modalEditar.php'); ?>
                <!--Ventana Modal para la Alerta de Eliminar--->
                <?php include('modalEliminar.php'); ?>
            <?php
            }
            ?>
        </tbody>
    </table>