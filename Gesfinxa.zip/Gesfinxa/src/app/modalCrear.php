<div class="modal fade" id="subir" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #84AC16 !important;">
                <h6 class="modal-title" style="color: #fff; text-align: center;">
                    Rellena la información para añadir un nuevo artículo
                </h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form id="frmajax" method="POST" enctype="multipart/form-data">

                <div class="modal-body" id="cont_modal">
                    <div class="form-group">
                        <strong><label for="recipient-name" class="col-form-label">Titulo de la Finca:</label></strong>
                        <input type="text" id="titulo" name="titulo" class="form-control" required="true">
                    </div>
                    <div class="form-group">
                        <strong><label for="recipient-name" class="col-form-label">N° de m²:</label></strong>
                        <input min="1" type="number" id="metros" name="metros" class="form-control" required="true">
                    </div>
                    <div class="form-group">
                        <strong><label for="recipient-name" class="col-form-label">N° de habitaciones:</label></strong>
                        <input min="0" type="number" id="habitaciones" name="habitaciones" class="form-control">
                    </div>
                    <div class="form-group">
                        <strong><label for="recipient-name" class="col-form-label">Precio:</label></strong>
                        <input min="100" step="50" type="number" name="precio" id="precio" class="form-control">
                    </div>

                    <div class="form-group">
                        <strong><label for="recipient-name" class="col-form-label">Imagen</label></strong>
                        <input type="file" id="imagen" name="imagen" accept="image/png,image/gif,image/jpeg,image/jpg" class="form-control">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" data-dismiss="modal" id="anyadir" name="anyadir" class="btn btn-success">Añadir</button>

                </div>
            </form>

        </div>
    </div>
</div>
