  <?php
    error_reporting(0);
    session_start();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        require "./PHPMailer/Exception.php";
        require "./PHPMailer/PHPMailer.php";
        require "./PHPMailer/SMTP.php";

        $msj = "";
        $email = $_POST['email'];
        $nom = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $msg = $_POST['mensaje'];

        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'tls';
        $mail->Username = 'provahostingraul@gmail.com';
        // $mail->Password = 'wypqcsmrfntnxonh';
        $mail->Password = 'fokbptunfwspahuk';
        $contingut = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-weight: 300;
                    line-height: 1.42em;
                    color: grey;
                    background-color: grey;
                }
                li{
                    color:black;
                    font-weight: bold;

                    
                }
                h1 {
                    font-size: 2em;
                    font-weight: 300;
                    line-height: 1em;
                    text-align: center;
                    color: blue;
                }

                p{
                    color: grey;
                    font-weight: bold;
                }
        
            </style>
        </head>
        <body> 
            <hr>
            <h1>DATOS</h1>
            <table class="container">

                    <ul>
                        <li type="circle">NOMBRE: <p>' . $nom . '</p></li>
                        <li type="circle">APELLIDOS: <p>' . $apellido . '</p></li>
                        <li type="circle">CORREO: <p>' . $email . '</p></li>
                        <li type="circle">MENSAJE: <p>' . $msg . '</p></li>
                    </ul>
        </body>
        </html>
        ';



        $mail->setFrom($email, $nom);
        $mail->addAddress('provahostingraul@gmail.com');
        $mail->addReplyTo($email, $nom);

        $mail->isHTML(true);
        $mail->Subject = 'Enviado por ' . $nom;
        $mail->MsgHTML($contingut);

        if (!$mail->send()) {
            $msj =  '<font color="red">Algo ha ido mal</font>';
        } else {
            $msj = '<font color="green">Mensaje enviado correctamente</font>';
            // Evita volver a enviar el formulario cuando se recarga la pagina
            echo "<META HTTP-EQUIV='Refresh' CONTENT='0; url=index.php'>";
        }
    }
    ?>

  <section id="contact">
      <div class="container">
          <div class="row">
              <div class="col-md-6 mt-4">

                  <h3>Contacta con nosotros</b></h3>
                  <p>Si tienes alguna duda o sugerencia , rellena debidamente el siguiente formulario y nos pondremos
                      en contacto a la mayor brevedad.</p><br>
              </div>


              <div class="col-md-6 mt-4">
                  <form name="contact" action="" method="post" onSubmit="return enviado()">
                      <div class="row">
                          <div class="col-md-6">

                              <div class="form-group">
                                  <input style="border-color: black; text-transform:capitalize;" type="text" class="form-control" id="nombre" name="nombre" placeholder="Name" required>
                              </div>
                          </div>
                          <div class="col-md-6">
                              <div class="form-group">
                                  <input style="border-color: black; text-transform:capitalize;" type="text" class="form-control" id="apellido" name="apellido" placeholder="Last name" required>
                              </div>
                          </div>
                          <div class="col-md-12">
                              <div class="form-group">
                                  <input value="<?php echo $_SESSION['correoLogado']; ?>" style="border-color: black;" type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                              </div>
                          </div>
                          <div class="col-md-12">
                              <div class="form-group">
                                  <textarea name="mensaje" style="border-color: black; border-radius:5px; text-transform:capitalize;" rows="4" cols="50" id="mensajeForm" class="form-control" placeholder="Escribe un mensaje..." required></textarea>
                              </div>
                          </div>
                          <div class="col-md-4">
                              <button id="mail" type="submit" value="" name="submit" class="btn btn-success">Enviar</button>
                          </div>
                      </div>
                      <b>
                          <span style="text-align:center;"><?= $msj; ?></span>
                      </b>
                  </form>
              </div>

          </div>
      </div>
  </section>

  <script>
      var cuenta = 0;

      function enviado() {
          if (cuenta == 0) {
              cuenta++;
              return true;
          } else {
              return false;
          }
      }
  </script>