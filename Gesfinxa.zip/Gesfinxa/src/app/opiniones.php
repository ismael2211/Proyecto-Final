<section id="opiniones" class="divider">
        <div class="container">
            <div class="content-center">
                <h2><b>Unas palabras de nuestros clientes...</b></h2>
                <p>Uno de los puntos más importantes de nuestra empresa, son las opiniones de nuestros clientes.</p>
            </div>
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="carousel-container">
                            <p> <img src="assets/images/qm1.png" width="20px" height="20px" style="margin-bottom: 40px;">&nbsp;Contento con el servicio. Muy profesionales y trabajadores, volveré a confiar en vosotros.&nbsp;<img src="assets/images/qm2.png" width="20px" height="20px" style="margin-bottom: 40px;">
                            </p>
                            <div class="rating">
                                <ul class="list-inline">
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                </ul>
                            </div>
                            <div class="testimonial-user">
                                <div class="row">
                                    <div class="col-md-3 col-3">
                                        <img src="assets/images/member-01.png" class="img-fluid" alt="">
                                    </div>
                                    <div class="col-md-9 col-9">
                                        <h6>Luis Cuenca</h6>
                                        <span>Inversor Financiero</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carousel-container">
                            <p><img src="assets/images/qm1.png" width="20px" height="20px" style="margin-bottom: 40px;">&nbsp;Todo correcto hasta la fecha, eficientes y muy bien atendidos.&nbsp;<img src="assets/images/qm2.png" width="20px" height="20px" style="margin-bottom: 40px;"></p>
                            <div class="rating">
                                <ul class="list-inline">
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>


                                </ul>
                            </div>
                            <div class="testimonial-user">
                                <div class="row">
                                    <div class="col-md-3 col-3">
                                        <img src="assets/images/member-02.jpg" class="img-fluid" alt="">
                                    </div>
                                    <div class="col-md-9 col-9">
                                        <h6>Maria Garcia</h6>
                                        <span>Administrativa</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="carousel-container">
                            <p><img src="assets/images/qm1.png" width="20px" height="20px" style="margin-bottom: 40px;">&nbsp;Hemos alquilado un piso a través de esta agencia y todo ha sido perfecto y rápido. Tuvimos un agente muy agradable y atento. Los recomiendo 100%.&nbsp;<img src="assets/images/qm2.png" width="20px" height="20px" style="margin-bottom: 40px;"></p>
                            <div class="rating">
                                <ul class="list-inline">
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                    <li class="list-inline-item"><i class="icon ion-md-star"></i></li>

                                </ul>
                            </div>
                            <div class="testimonial-user">
                                <div class="row">
                                    <div class="col-md-3 col-3">
                                        <img src="assets/images/member-03.jpg" class="img-fluid" alt="">
                                    </div>
                                    <div class="col-md-9 col-9">
                                        <h6>Jose Torregrosa</h6>
                                        <span>Professor de Secundaria</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <div class="control-button">
                        <img src="assets/images/arrow-borderless-left.svg" class="img-fluid">
                    </div>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <div class="control-button">
                        <img src="assets/images/arrow-borderless-right.svg" class="img-fluid">
                    </div>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </section>