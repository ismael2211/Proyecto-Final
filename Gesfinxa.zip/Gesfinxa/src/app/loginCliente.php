<?php
error_reporting(0);
session_start();
?>

<div class="row l">
    <div class="col-lg-4 col-md-6">
        <div class="pricing-container">
            <div style="margin-top: 60px;" class="plans plan-light">
                <h4><b>LOGIN</b></h4>
                <p class="text-warning text-center">Rellena tus datos</p>
                <div id="contact_form">
                    <form name="contact" action="">
                        <fieldset>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                                    </div>
                                    <input id="correo" name="correo" class="form-control" value="" placeholder="Email or login" type="email">
                                </div>
                                <span style="color: red; font-weight:bold;" class="error" id="correo_error">El correo no puede estar vacio</span>
                                <!-- input-group.// -->
                            </div>
                            <br><br>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                    </div>
                                    <input id="contra" name="contra" class="form-control" value="" placeholder="********" type="password">
                                </div> <!-- input-group.// -->
                                <span style="color: red; font-weight:bold;" class="error" id="contra_error">La contraseña no puede estar vacia</span>
                            </div>
                            <b><span style="color:green" id="mensaje"></span></b>
                            <button type="button" value="" name="submit" id="submit_btn" class="btn btn-white btn btn-outline-dark full-width mt-4 sm">Iniciar Sesión</button>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!--Si el usuario ha iniciado sesión, no deja volver a iniciar sesión con otro usuario a no ser que haga logout -->
    <?php if (!empty($_SESSION['correoLogado'])) { ?>
        
        <script>
            document.getElementById("submit_btn").disabled = true;
        </script>
    <?php } else { ?>
        <script>
            document.getElementById("submit_btn").disabled = false;
        </script>
    <?php } ?>