<?php
error_reporting(0);
session_start();
?>
<section id="inmo" class="bgLightGrey">
    <div class="container" id="container">
        <div class="content-center">
            <h2><b>INMOBILIARIA</b></h2>
            <p>En DVS-B Gesfinxa tenemos un servicio de gestión adaptado a tus necesidades.<br>
                Aqui tenemos alguno de nuestros servicios disponibles
            </p>
            <!-- <button type="button" class="btn btn-primary" id="boton">Mostrar Mas</button> -->
            <?php if (!empty($_SESSION['correoLogado'])) {
            ?>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#subir">Crear nuevo</button>
            <?php } ?>
        </div>
        <?php
        // Cargamos el archivo de modalCrear para tener el modal de crear una nueva finca
        include "modalCrear.php";
        ?>
        <div style="text-align:center; display:none;" class="alert" id="respuesta">
        </div>
        <section id="galeria">
            <?php
            // Cargamos el archivo mostrarFincas con la informción de la BD
            include "mostrarFincas.php";
            ?>
        </section>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('.zoom').hover(function() {
            $(this).addClass('transition');

        }, function() {
            $(this).removeClass('transition');

        });
    });
</script>

<style>
    a {
        text-decoration: none;
        color: #036;
    }

    #galeria {
        margin: 1rem auto;
        width: 100%;
        max-width: 960px;
        padding: 0 20px 20px;
        box-sizing: border-box;
        column-count: 3;

        border-radius: 10px;
        padding: 10px;

        /* Espacio entre columnas */
        -moz-column-gap: 20px;
        -webkit-column-gap: 20px;
        column-gap: 20px;

    }

    #galeria header {
        -webkit-column-span: all;
        column-span: all;
    }

    article {
        background: #fff;
        border-radius: 8px;
        border: 2px solid #ccc;
        margin: 0 0 20px 0;
        text-align: center;
        max-width: 100%;
        filter: opacity(80%);

        /*Evitamos que se corte al cambiar de columna*/
        break-inside: avoid;
        page-break-inside: avoid;

    }

    article img {
        width: 100%;
        border-radius: 5px;
    }

    article:hover {
        transition: .5s ease;
        filter: opacity(100%);


    }

    figure {
        padding: 1rem;
        box-sizing: border-box;


    }


    /* Móviles en horizontal o tablets en vertical */
    @media (max-width: 767px) {
        #galeria {
            columns: 2;
        }

    }

    /* Móviles en vertical */

    @media (max-width: 480px) {
        #galeria {
            columns: 1;
        }
    }

    img.zoom {
        -webkit-transition: all .2s ease-in-out;

    }

    .transition {
        -webkit-transform: scale(1.8);
        border-radius: 10px;

    }

    figcaption>h5 {
        color: black !important;
    }
</style>