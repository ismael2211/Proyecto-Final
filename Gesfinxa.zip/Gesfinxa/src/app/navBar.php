<?php
error_reporting(0);
session_start();

?>
<nav id="main-nav" class="navbar navbar-expand-lg fixed-top j">

    <div class="container" id="nav">
        <div id="google_translate_element" class="google"></div> &nbsp;&nbsp;&nbsp;

        <script type="text/javascript">
            function googleTranslateElementInit() {
                new google.translate.TranslateElement({
                    pageLanguage: 'es',
                    includedLanguages: 'ca,en,fr,it',
                    layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
                    gaTrack: true
                }, 'google_translate_element');
            }
        </script>

        <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

        <span style="font-size: 15px; display: none;" id="userlogin"></span>&nbsp;&nbsp;&nbsp;<a style="color:#0D869C; display:none; font-size:20px; font-weight: bold;" id="logout" href="./databases/logout.php">Logout</a>
        <img src="assets/images/logo.png" class="logo-brand" alt="logo">
        <button id="b" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <img src="assets/images/menu.svg">
        </button>


        <?php if (!empty($_SESSION['correoLogado'])) { ?>

            <script>
                const userlogin = "<?= $_SESSION['correoLogado']; ?>"
                document.getElementById("userlogin").innerHTML = "Hola, " + '<b>' + userlogin + '</b>';
                document.getElementById('userlogin').style.display = "block";
                document.getElementById('logout').style.display = "block";
            </script>
        <?php } else { ?>
            <script>
                document.getElementById('logout').style.display = "none";
                document.getElementById('userlogin').style.display = "none";
            </script>
        <?php } ?>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"></li>
                <a class="nav-link n" href="#home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link n" href="#inicioSesion">Inicio Sesión</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link n" href="#inmo">Inmobiliaria</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link n" href="#portfolio">Portfolio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link n" href="#opiniones">Opiniones</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link n" href="#contact">Contacto</a>
                </li>
            </ul>
        </div>
    </div>
    </div>
</nav>

<style>
    .goog-te-combo,
    .goog-te-banner *,
    .goog-te-ftab *,
    .goog-te-menu *,
    .goog-te-menu2 *,
    .goog-te-balloon * {
        font-family: arial;
        font-size: 10pt;
        display: none;
    }
</style>