<div class="col-lg-4 col-md-6">
    <div class="pricing-container">
        <div class="plans plan-dark">
            <h4><b>REGISTRO</b></h4>
            <p class="text-warning text-center">Rellena tus datos</p>
            <form action="" id="basic-form">
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fas fa-address-card"></i> </span>
                        </div>
                        <input style="text-transform: capitalize" id="nombre1" name="nombre" placeholder="Name" type="text" size="35" class="form-control">
                    </div> <!-- input-group.// -->
                    <span style="color: red;" class="error" id="nombre_error1">El nombre no puede estar vacio</span>
                </div><br>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                        </div>
                        <input id="correo1" name="correo" class="form-control" placeholder="Email or login" type="email" size="35">
                    </div> <!-- input-group.// -->
                    <span style="color: red" class="error" id="correo_error1">El correo no puede estar vacio</span>
                    <span style="color: red" class="error" id="correo_error2">El correo debe contener formato "user@gmail.com"</span>

                </div><br>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                        </div>
                        <input type="password" id="contra1" name="contra" placeholder="********" size="35" class="form-control">
                    </div>
                    <span style="color: red" class="error" id="contra_error1">La contraseña no puede estar vacia</span>
                    <span style="color: red" class="error" id="contra_error2">La contraseña debe contener ocho caracteres, al una letra y un número</span>
                </div><br>
                <b><span style="color:green" id="registro"></span></b>
                <button type="button" value="" name="submit" id="submit_btn1" class="btn btn-dark btn btn-outline-light full-width mt-4">Registrarse</button>
            </form>
        </div>
    </div>
</div>
</div>
</div>
</section>