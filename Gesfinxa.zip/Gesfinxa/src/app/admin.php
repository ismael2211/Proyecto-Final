<?php
session_start();
$connexio = mysqli_connect('localhost', 'root', '', 'clientes');
var_dump($_SESSION);

?>

<div style="text-align: center;" id="admin">
    <!-- Aunque se recargue la pagina no desaparecerá la pestaña de admin -->
    <?php if (!empty($_SESSION['correoLogado'])) {
        if ($_SESSION['correoLogado'] == "admin@gmail.com") {
            include('mostrarTaula.php');
    ?>
            <script>
                document.getElementById("userlogin").innerHTML = "Hola, " + '<b><i>' + userlogin + '</i></b>';
                document.getElementById('admin').style.display = "block";
            </script>
        <?php
        } else {
        ?>
            <script>
                document.getElementById('admin').style.display = "none";
            </script>
        <?php } ?>

    <?php } else { ?>
        <script>
            document.getElementById('userlogin').style.display = "none";
        </script>
    <?php } ?>



</div><br>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        var admin = document.getElementById("admin");
        $('.btnBorrar').click(function(e) {
            e.preventDefault();
            var id = $(this).attr("id");
            $.ajax({
                type: "POST",
                url: "./databases/eliminar.php",
                data: 'id=' + id,
                success: function(r) {
                    $('#delete').modal('hide');
                    $.ajax({
                        type: "GET",
                        url: "./app/mostrarTaula.php",
                        success: function(r) {
                            admin.innerHTML = r;
                            // $('#delete'+id).modal('hide');
                        }
                    });

                }
            });
            return false;
        });
    });
</script>
<style>
    .table {
        width: 70%;
        text-align: center;

    }
</style>