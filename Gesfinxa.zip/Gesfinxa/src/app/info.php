<section id="info" class="bgLightGrey" style="display:none;">
    <div class="container">
        <div class="content-center" style="padding: 0;">
            <h2><b>Información</b></h2>
            <p>
                A parte de nuestra pagina web , también contamos con una oficina en la localidad de Xátiva(Valéncia)
            </p>
            <button type="button" class="btn btn-info" id="ocultar">Ocultar</button>
        </div>

        <div class="container gallery-container" id="c"><br>
            <table class="table table-dark table-responsive-md" style="margin: 0 auto; border-radius:10px; padding:5px">
                <thead>
                    <tr>
                        <th scope="col">Lunes</th>
                        <th scope="col">Martes</th>
                        <th scope="col">Miercoles</th>
                        <th scope="col">Jueves</th>
                        <th scope="col">Viernes</th>
                        <th scope="col">Sabado</th>
                        <th scope="col">Domingo</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-secondary">9:00 a 14:00</td>
                        <td class="text-secondary">9:00 a 14:00</td>
                        <td class="text-secondary">9:00 a 14:00</td>
                        <td class="text-secondary">9:00 a 14:00</td>
                        <td class="text-secondary">9:00 a 14:00</td>
                        <td class="text-danger">Cerrado</td>
                        <td class="text-danger">Cerrado</td>
                    </tr>
                    <tr>
                        <td class="text-secondary">17:00 a 20:00</td>
                        <td class="text-secondary">17:00 a 20:00</td>
                        <td class="text-secondary">17:00 a 20:00</td>
                        <td class="text-secondary">17:00 a 20:00</td>
                        <td class="text-danger">Cerrado</td>
                        <td class="text-danger">Cerrado</td>
                        <td class="text-danger">Cerrado</td>
                    </tr>
                </tbody>
            </table>
            <div class="tz-gallery">
            <div style="width: 100%"><iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=400&amp;hl=en&amp;q=Bajada%20Estaci%C3%B3,%207,%2046800%20X%C3%A0tiva,%20Valencia+(GESFINXA)&amp;t=&amp;z=16&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a href="http://www.gps.ie/">truck gps</a></iframe></div>                <div class="row">

                </div>

            </div>

        </div>
    </div>
</section>

<script>
    var bot = document.getElementById("pulsar");
    bot.addEventListener("click" , mostrar);


    function mostrar(){
        document.getElementById("info").style.display = 'block';
    }

    var bot1 = document.getElementById("ocultar");
    bot1.addEventListener("click" , () => {
        document.getElementById("info").style.display = 'none';
    })
    
</script>