
$(document).ready(() => {
    $('#correo1').on('click', function () {
        $("#correo_error1").hide();
    });
})
$(document).ready(() => {
    $('#contra1').on('click', function () {
        $("#correo_error2").hide();
    });
})
$(document).ready(() => {
    $('#nombre1').on('click', function () {
        $("#nombre_error1").hide();
    });
})
$(document).ready(() => {
    $('#contra1').on('click', function () {
        $("#contra_error1").hide();
    });
})


$(function () {
    $('.error').hide();
    $("#submit_btn1").click(function () {
        // validate and process form here

        // $('.error').hide();
        var nombre = $("input#nombre1").val();
        if (nombre === "") {
            $("#nombre_error1").show();
            $("#nombre_error1").fadeOut(2000);
            return false;
        }

        var correo = $("input#correo1").val();
        if (correo === "") {
            $("#correo_error1").show();
            $("#correo_error1").fadeOut(2000);
            return false;
        }
        var expr = /^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$/;
        if (!expr.test(correo)) {
            $("#correo_error2").show();
            $("#correo_error2").fadeOut(2000);
            return false;
        }
        var contra = $("input#contra1").val();
        if (contra === "") {
            $("#contra_error1").show();
            $("#contra_error1").fadeOut(2000);
            return false;
        }
        var val = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
        if (!val.test(contra)) {
            $("#contra_error2").show();
            $("#contra_error2").fadeOut(4000);
            return false;
        }
        $('#contra1').on('focus', function () {
            $("#contra_error2").empty();
        })

        let dataString = {
            'correo': correo,
            'nombre': nombre,
            'contra': contra
        }


        var exito = "Usuario registrado correctamente";
        var error = "Email existente";
        $.ajax({
            type: "POST",
            url: "./databases/registro.php",
            data: dataString,
            success: function (respuesta) {
                $("input#nombre1").val("");
                $("input#correo1").val("");
                $("input#contra1").val("");
                if (respuesta == 1) {
                    $('#registro').css('color', 'red');
                    $("#registro").html(error).fadeOut(3000);
                    $("input#nombre1").val("");
                    $("input#correo1").val("");
                    $("input#contra1").val("");

                } else {
                    $('#registro').css('color', 'green');
                    $("#registro").html(exito).fadeOut(3000);
                    $("#contra_error2").empty();
                    $("#correo_error2").empty();
                    $("#nombre").val("");
                    $("#correo").val("");
                    $("#contra").val("");
                }


            }
        });
        return false;



    });

});