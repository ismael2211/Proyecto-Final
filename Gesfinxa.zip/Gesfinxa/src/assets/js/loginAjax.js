

$(document).ready(() => {
    $('#correo').on('click', function () {
        $("#correo_error").hide();
    });
})
$(document).ready(() => {
    $('#contra').on('click', function () {
        $("#contra_error").hide();
    });
})




$(function () {
    $('.error').hide();
    $("#submit_btn").on('click', function () {
        // validate and process form here

        // $('.error').hide();
        var correo = $("input#correo").val();
        if (correo === "") {
            $("#correo_error").show();
            $("#correo_error").fadeOut(2000);
            return false;
        }
        var contra = $("input#contra").val();
        if (contra === "") {
            $("#contra_error").show();
            $("#contra_error").fadeOut(2000);
            return false;
        }


        let dataString = {
            'correo': correo,
            'contra': contra
        }

        var tablaUsuarios = document.getElementById("admin");
        console.log(tablaUsuarios);
        var but = document.getElementById("submit_btn");
        var exito = "Sesion Iniciada";
        var error = "Email o contraseña erroneos";

        $.ajax({
            type: "POST",
            url: "./databases/login.php",
            data: dataString,
            cache: false,
            success: function (respuesta) {
                console.log(dataString)
                if (respuesta == 1) {

                    $("#mensaje").html(exito).fadeOut(3000);
                    $("input#nombre").val("");
                    $("input#correo").val("");
                    $("input#contra").val("");
                    //Dar la bienvenida al usuario logeado
                    document.getElementById("userlogin").innerHTML = "Hola, " + "<b>" + dataString.correo + "</b>";
                    $("#userlogin").css('display', 'block');
                    //Si un usuario ha iniciado sesión que aparezca el logout
                    $("#logout").css('display', 'block');
                    // $("#subir").css('display','block');
                    //Deshabilitar boton de inicio de sesión
                    but.disabled = true;

                    //Si la respuesta es 2 , se inició sesión con "admin"
                } else if (respuesta == 2) {

                    $.ajax({
                        type: "GET",
                        url: "./app/mostrarTaula.php",
                        success: function (r) {
                            tablaUsuarios.innerHTML = r;
                        }
                    });
                    $("#mensaje").html(exito).fadeOut(3000);
                    $("input#nombre").val("");
                    $("input#correo").val("");
                    $("input#contra").val("");
                    //Dar la bienvenida al usuario logeado
                    document.getElementById("userlogin").innerHTML = "Hola, " + '<b><i>' + dataString.correo + '</i></b>';
                    //Si se ha iniciado sesión como admin aparecerá una tabla para modificar los usuarios
                  
                    

                    // $("#admin").css('display', 'block');
                    $("#userlogin").css('display', 'block');
                    //Si un usuario ha iniciado sesión que aparezca el logout
                    $("#logout").css('display', 'block');
                    but.disabled = true;
                } else {
                    $('#mensaje').css('color', 'red');
                    $("#mensaje").html(error).fadeOut(3000);
                    $("input#nombre").val("");
                    $("input#correo").val("");
                    $("input#contra").val("");
                    //Si un usuario ha cerrado sesión que desaparezca el logout
                    $("#logout").css('display', 'none');
                    $("#userlogin").css('display', 'none');
                }

            }

        });

        return false;

    });

});

