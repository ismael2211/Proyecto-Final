$(document).ready(function() {
    $('#anyadir').click(function() {
        var titulo = $("input#titulo").val();
        var metros = $("input#metros").val();
        var precio = $("input#precio").val();
        var habitaciones = $("input#habitaciones").val();
        var imagen = $("input#imagen")[0].files[0];
        var section = document.getElementById("galeria");
        var datos = {
            'titulo': titulo,
            'metros': metros,
            'precio': precio,
            'habitaciones': habitaciones,
            'imagen': imagen
        }
        $.ajax({
            type: "POST",
            url: "./databases/i.php",
            data: datos,
            contentType: false,
            processData: false,
            success: function(r) {
                if (r == 1) {
                    $('#subir').modal('hide');
                    $("#respuesta").css("display", "block");
                    $("#respuesta").html("Error al añadir").addClass("alert-danger").fadeOut(2500);
                } else {
                    $('#subir').modal('hide');
                    $("#respuesta").css("display", "block");
                    $("#respuesta").html("Añadido con Exito!").addClass("alert-primary").fadeOut(2500);
                    $.ajax({
                        type: "GET",
                        url: "./app/mostrarFincas.php",
                        success: function(r) {
                            $("input#titulo").val("");
                            $("input#metros").val("");
                            $("input#precio").val("");
                            $("input#habitaciones").val("");
                            section.innerHTML = r;
                        }
                    });
                }
            }
        });
        return false;
    });

});
