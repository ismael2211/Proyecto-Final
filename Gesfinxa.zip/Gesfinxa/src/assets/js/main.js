window.addEventListener("load", () => {


  new Typed('#typed', {
    strings: ['<h1 style="display:inline; color:blue;">24 HORAS</h1>'],
    typeSpeed: 150,
    delaySpeed: 100,
    loop: true
  });


  // Mostrar tabla de información de horarios.
  var bot = document.getElementById("pulsar");
    bot.addEventListener("click" , mostrar);


    function mostrar(){
        document.getElementById("info").style.display = 'block';
    }

    var bot1 = document.getElementById("ocultar");
    bot1.addEventListener("click" , () => {
        document.getElementById("info").style.display = 'none';
    })

  // var boton = document.getElementById("boton");
  // boton.addEventListener("click", cargar);

  // function cargar() {
  //   document.getElementById("element").style.display = 'block';
  //   document.getElementById("element1").style.display = 'block';
  //   document.getElementById("element2").style.display = 'block';

  //   if (boton.innerHTML == 'Mostrar Mas')
  //     boton.innerHTML = "Mostrar Menos";
  //   else boton.innerHTML = 'Mostrar Mas';

  //   if (boton.innerHTML == 'Mostrar Mas') {
  //     document.getElementById("element").style.display = 'none';
  //     document.getElementById("element1").style.display = 'none';
  //     document.getElementById("element2").style.display = 'none';
  //   }
  // }
  
})
