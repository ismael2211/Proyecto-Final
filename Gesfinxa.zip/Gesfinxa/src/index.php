<?php
session_start();
?>
<!doctype html>
<html lang="es">

<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Font awesome Bootstrap -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
    <!-- Efecto Lightbox -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- Style -->
    <link rel="stylesheet" href="assets/css/styles.css" type="text/css">
    <script type="text/javascript" src="../node_modules/alertify.js"></script>
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:400,600" rel="stylesheet">

    <!-- Ionic icons-->
    <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">


    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images//favicon.ico" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    


    <title>DVS-B | Gesfinxa</title>
</head>
<body>

    <section id="home">
        <div class="container">
            <div class="content-center">
                <h1 class="mt-5"><b><i style="color:white!important;">DVS-B | GESFINXA</i></b></h1>
                <p style="margin-top: 75px; font-size:35px; font-weight:bold">Administración y Gestión de Fincas</p>
            </div>
        </div>
    </section>

    <section id="inicioSesion" class="divider">
        <div class="container">
            <div class="content-center">
                <h2>Formularios</b></h2>
                <p><b>Regístrate o inicia sesión para realizar algunas de nuestras tareas exclusivas.</b></p>
            </div>
            <?php
            include("app/navBar.php");
            include("app/loginCliente.php");
            include("app/registroCliente.php");
            include("app/admin.php");
            include("app/inmobiliaria.php");
            include("app/portfolio.php");
            include("app/info.php");
            include("app/opiniones.php");
            include("app/contact.php");
            include("app/footer.php");
            ?>
            <!-- Ajax -->

            <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
            <script src="./assets/js/loginAjax.js"></script>
            <script src="./assets/js/registroAjax.js"></script>
            <script src="./assets/js/añadir.js"></script>
            <script src="./assets/js/main.js"></script>
            <!-- JavaScript -->
            
            <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.11"></script>

            <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
            <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
            <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

</body>

</html>
